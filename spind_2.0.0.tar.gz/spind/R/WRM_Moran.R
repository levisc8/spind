wrm.moran<-function(lim1=0,increment=1){

  moran.list<-list(lim1=lim1,increment=increment)
  return(moran.list)
}
