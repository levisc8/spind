wrm.control<-function(eps=1e-5,denom.eps=1e-20,itmax=200){

  contr.list<-list(eps=eps,denom.eps=denom.eps,itmax=itmax)
  return(contr.list)
}
#
