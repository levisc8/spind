wrm.pad<-function(padform=0,padzone=1){

  pad.list<-list(padform=padform,padzone=padzone)
  return(pad.list)
}
